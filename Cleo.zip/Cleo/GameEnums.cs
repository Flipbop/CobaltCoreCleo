﻿using Nanoray.EnumByNameSourceGenerator;

namespace Flipbop.Cleo;

[EnumByName(typeof(Spr))]
internal static partial class StableSpr;