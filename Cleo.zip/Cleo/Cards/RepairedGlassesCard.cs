using Nanoray.PluginManager;
using Nickel;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Flipbop.Cleo;

internal sealed class RepairedGlassesCard : Card, IRegisterable
{
	public static void Register(IPluginPackage<IModManifest> package, IModHelper helper)
	{
		helper.Content.Cards.RegisterCard(MethodBase.GetCurrentMethod()!.DeclaringType!.Name, new()
		{
			CardType = MethodBase.GetCurrentMethod()!.DeclaringType!,
			Meta = new()
			{
				deck = ModEntry.Instance.CleoDeck.Deck,
				rarity = ModEntry.GetCardRarity(MethodBase.GetCurrentMethod()!.DeclaringType!),
				upgradesTo = [Upgrade.A, Upgrade.B]
			},
			Name = ModEntry.Instance.AnyLocalizations.Bind(["card", "RepairedGlasses", "name"]).Localize
		});
	}

	private int CardCount
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get => upgrade switch
		{
			Upgrade.A => 6,
			Upgrade.B => 3,
			_ => 4
		};
	}

	public override CardData GetData(State state)
		=> new()
		{
			artTint = "FFFFFF",
			art = StableSpr.cards_SecondOpinions,
			cost = 0,
			exhaust = upgrade != Upgrade.B,
		};

	public override List<CardAction> GetActions(State s, Combat c)
		=> [
			new ACardOffering
			{
				amount = CardCount,
				makeAllCardsTemporary = true,
				overrideUpgradeChances = false,
				canSkip = false,
				inCombat = true
			}
		];
}
